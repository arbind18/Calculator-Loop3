import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Moon, Sun, Home } from "lucide-react";
import { useTheme } from "next-themes";
import { useNavigate } from "react-router-dom";

interface CalculatorLayoutProps {
  title: string;
  description: string;
  icon: string;
  children: ReactNode;
}

const CalculatorLayout = ({ title, description, icon, children }: CalculatorLayoutProps) => {
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background dark:bg-[#0A0E27] transition-colors duration-200">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-glass-border">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/")}
                className="rounded-xl glass-effect"
              >
                <Home className="h-5 w-5" />
              </Button>
              <div className="flex flex-col">
                <h1 className="font-manrope text-xl lg:text-2xl font-extrabold gradient-text">
                  Calculator Loop
                </h1>
              </div>
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="rounded-xl glass-effect"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-16 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Calculator Header */}
          <div className="mb-8 lg:mb-12 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan to-purple mb-4 text-4xl shadow-xl">
              {icon}
            </div>
            <h2 className="font-manrope text-3xl lg:text-4xl font-bold mb-3">{title}</h2>
            <p className="text-text-secondary text-lg max-w-2xl mx-auto">{description}</p>
          </div>

          {/* Calculator Content */}
          {children}
        </div>
      </main>
    </div>
  );
};

export default CalculatorLayout;
