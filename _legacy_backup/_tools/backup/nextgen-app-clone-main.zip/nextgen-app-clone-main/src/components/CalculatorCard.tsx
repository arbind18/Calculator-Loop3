import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface CalculatorCardProps {
  icon: string;
  title: string;
  description: string;
  category: string;
  path?: string;
  featured?: boolean;
}

const CalculatorCard = ({ icon, title, description, category, path, featured }: CalculatorCardProps) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (path) {
      navigate(path);
    }
  };

  return (
    <Card
      onClick={handleClick}
      className={`group relative overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-2xl ${
        featured
          ? "bg-gradient-to-br from-card via-card to-cyan/5 dark:to-cyan/10"
          : "bg-card"
      } border border-glass-border hover:border-cyan/50 cursor-pointer`}
    >
      {/* Animated gradient border on hover */}
      <div className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-cyan via-purple to-cyan bg-[length:200%_100%] animate-[gradient_3s_ease_infinite] p-[2px]">
        <div className="w-full h-full bg-card dark:bg-[#1A1F3A] rounded-lg" />
      </div>

      {/* Content */}
      <div className="relative p-6 flex flex-col h-full">
        {/* Icon and Category */}
        <div className="flex items-start justify-between mb-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan to-purple flex items-center justify-center text-2xl group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300 shadow-lg">
            {icon}
          </div>
          <span className="text-xs px-3 py-1 rounded-full bg-muted text-text-secondary font-medium">
            {category}
          </span>
        </div>

        {/* Title and Description */}
        <div className="flex-grow mb-4">
          <h4 className="font-manrope text-lg font-bold mb-2 group-hover:text-cyan transition-colors">
            {title}
          </h4>
          <p className="text-sm text-text-secondary line-clamp-2">{description}</p>
        </div>

        {/* Action Button */}
        <Button
          className="w-full gradient-bg text-white font-semibold rounded-xl group-hover:shadow-lg group-hover:shadow-cyan/50 transition-all duration-300"
          size="lg"
        >
          Calculate Now
          <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </Button>
      </div>
    </Card>
  );
};

export default CalculatorCard;
