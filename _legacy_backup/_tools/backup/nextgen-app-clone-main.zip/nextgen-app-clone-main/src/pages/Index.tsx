import { useState } from "react";
import { Search, Moon, Sun } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import CalculatorCard from "@/components/CalculatorCard";
import { useTheme } from "next-themes";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  const popularCalculators = [
    { icon: "💰", title: "EMI Calculator", description: "Calculate monthly loan payments", category: "Financial", path: "/calculator/emi" },
    { icon: "📈", title: "SIP Calculator", description: "Plan your SIP investments", category: "Financial", path: "/calculator/sip" },
    { icon: "⚖️", title: "BMI Calculator", description: "Check your body mass index", category: "Health", path: "/calculator/bmi" },
    { icon: "📊", title: "GST Calculator", description: "Calculate GST on products", category: "Financial", path: "/calculator/gst" },
    { icon: "🎂", title: "Age Calculator", description: "Calculate your exact age", category: "Date & Time", path: "/calculator/age" },
    { icon: "🏦", title: "Loan Calculator", description: "Calculate loan repayments", category: "Financial", path: "/calculator/emi" },
  ];

  const allCalculators = [
    { icon: "💵", title: "Income Tax Calculator", description: "Calculate your income tax", category: "Financial", path: "/calculator/emi" },
    { icon: "🏡", title: "Mortgage Calculator", description: "Calculate home loan EMI", category: "Financial", path: "/calculator/emi" },
    { icon: "💪", title: "Calorie Calculator", description: "Calculate daily calories", category: "Health", path: "/calculator/bmi" },
    { icon: "🎓", title: "GPA Calculator", description: "Calculate your GPA score", category: "Education", path: "/calculator/age" },
    { icon: "📉", title: "Discount Calculator", description: "Calculate sale discounts", category: "Shopping", path: "/calculator/gst" },
    { icon: "🌡️", title: "BMR Calculator", description: "Calculate basal metabolic rate", category: "Health", path: "/calculator/bmi" },
    { icon: "💱", title: "Currency Converter", description: "Convert currencies", category: "Finance", path: "/calculator/gst" },
    { icon: "📏", title: "Unit Converter", description: "Convert units easily", category: "Math", path: "/calculator/age" },
    { icon: "🔢", title: "Percentage Calculator", description: "Calculate percentages", category: "Math", path: "/calculator/gst" },
    { icon: "⏰", title: "Time Calculator", description: "Calculate time differences", category: "Date & Time", path: "/calculator/age" },
    { icon: "🎯", title: "Tip Calculator", description: "Calculate tip amounts", category: "Everyday", path: "/calculator/gst" },
    { icon: "🧮", title: "Scientific Calculator", description: "Advanced calculations", category: "Math", path: "/calculator/age" },
  ];

  const filteredCalculators = searchQuery
    ? allCalculators.filter(
        (calc) =>
          calc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          calc.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allCalculators;

  return (
    <div className="min-h-screen bg-background dark:bg-[#0A0E27] transition-colors duration-200">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-glass-border">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <div className="flex flex-col">
              <h1 className="font-manrope text-2xl lg:text-3xl font-extrabold gradient-text">
                Calculator Loop
              </h1>
              <p className="text-xs text-text-secondary hidden sm:block">300+ Free Calculators</p>
            </div>

            {/* Desktop Search */}
            <div className="hidden md:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary" />
                <Input
                  type="text"
                  placeholder="Search calculators..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-glass-bg border-glass-border"
                />
              </div>
            </div>

            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="rounded-xl glass-effect"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden pb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary" />
              <Input
                type="text"
                placeholder="Search calculators..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-glass-bg border-glass-border"
              />
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-16">
        {/* Hero Section */}
        {!searchQuery && (
          <section className="py-12 lg:py-20 px-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan/10 via-transparent to-purple/10 pointer-events-none" />
            <div className="container mx-auto text-center relative z-10">
              <h2 className="font-manrope text-3xl lg:text-5xl xl:text-6xl font-bold mb-4 lg:mb-6">
                <span className="gradient-text">300+ Free Online</span>
                <br />
                <span className="text-foreground">Calculators</span>
              </h2>
              <p className="text-text-secondary text-base lg:text-lg max-w-2xl mx-auto mb-8">
                From financial planning to health metrics, make complex calculations simple with our comprehensive calculator suite.
              </p>
              <Button className="gradient-bg text-white font-semibold px-8 py-6 text-lg rounded-xl hover:scale-105 transition-transform shadow-lg hover:shadow-cyan/50">
                Explore All Calculators
              </Button>
            </div>
          </section>
        )}

        {/* Popular Calculators */}
        {!searchQuery && (
          <section className="py-8 lg:py-12 px-4">
            <div className="container mx-auto">
              <div className="text-center mb-8 lg:mb-12">
                <h3 className="font-manrope text-2xl lg:text-3xl font-bold mb-3">
                  Popular Calculators
                </h3>
                <p className="text-text-secondary">Most used calculators by our users</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
                {popularCalculators.map((calc, index) => (
                  <CalculatorCard key={index} {...calc} path={calc.path} featured />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* All Calculators */}
        <section className="py-8 lg:py-12 px-4">
          <div className="container mx-auto">
            <div className="text-center mb-8 lg:mb-12">
              <h3 className="font-manrope text-2xl lg:text-3xl font-bold mb-3">
                {searchQuery ? "Search Results" : "All Calculators"}
              </h3>
              {!searchQuery && (
                <p className="text-text-secondary">Browse through our complete collection</p>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6">
              {filteredCalculators.length > 0 ? (
                filteredCalculators.map((calc, index) => (
                  <CalculatorCard key={index} {...calc} path={calc.path} />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <p className="text-text-secondary text-lg">No calculators found matching "{searchQuery}"</p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-glass-border bg-secondary/50 py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="text-center lg:text-left">
              <h4 className="font-manrope text-xl font-bold gradient-text mb-1">Calculator Loop</h4>
              <p className="text-text-secondary text-sm">Your all-in-one calculator suite</p>
            </div>
            <div className="flex gap-6 text-sm text-text-secondary">
              <a href="#" className="hover:text-cyan transition-colors">About</a>
              <a href="#" className="hover:text-cyan transition-colors">Privacy</a>
              <a href="#" className="hover:text-cyan transition-colors">Terms</a>
              <a href="#" className="hover:text-cyan transition-colors">Contact</a>
            </div>
          </div>
          <div className="text-center mt-6 text-sm text-text-muted">
            © 2025 Calculator Loop. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
