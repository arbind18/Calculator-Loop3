import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import CalculatorLayout from "@/components/CalculatorLayout";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const SIPCalculator = () => {
  const [monthlyInvestment, setMonthlyInvestment] = useState<string>("10000");
  const [expectedReturn, setExpectedReturn] = useState<string>("12");
  const [timePeriod, setTimePeriod] = useState<string>("10");
  const [totalInvestment, setTotalInvestment] = useState<number>(0);
  const [estimatedReturns, setEstimatedReturns] = useState<number>(0);
  const [totalValue, setTotalValue] = useState<number>(0);
  const [chartData, setChartData] = useState<any[]>([]);

  const calculateSIP = () => {
    const P = parseFloat(monthlyInvestment);
    const r = parseFloat(expectedReturn) / 100 / 12; // Monthly rate
    const n = parseFloat(timePeriod) * 12; // Total months

    if (P > 0 && r > 0 && n > 0) {
      const futureValue = P * (((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const totalInvestedAmount = P * n;
      const totalReturns = futureValue - totalInvestedAmount;

      setTotalInvestment(Math.round(totalInvestedAmount));
      setEstimatedReturns(Math.round(totalReturns));
      setTotalValue(Math.round(futureValue));

      // Generate year-wise data for chart
      const yearData = [];
      for (let year = 1; year <= parseFloat(timePeriod); year++) {
        const months = year * 12;
        const value = P * (((Math.pow(1 + r, months) - 1) / r) * (1 + r));
        const invested = P * months;
        yearData.push({
          year: `Year ${year}`,
          invested: Math.round(invested),
          value: Math.round(value),
        });
      }
      setChartData(yearData);
    }
  };

  const pieData = [
    { name: "Invested Amount", value: totalInvestment },
    { name: "Estimated Returns", value: estimatedReturns },
  ];

  const COLORS = ["#00D4FF", "#8B5CF6"];

  return (
    <CalculatorLayout
      title="SIP Calculator"
      description="Calculate your Systematic Investment Plan returns over time"
      icon="📈"
    >
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Input Section */}
        <Card className="p-6 lg:p-8 glass-effect">
          <h3 className="font-manrope text-xl font-bold mb-6">Investment Details</h3>
          <div className="space-y-6">
            <div>
              <Label htmlFor="monthlyInvestment" className="text-base font-semibold mb-2 block">
                Monthly Investment (₹)
              </Label>
              <Input
                id="monthlyInvestment"
                type="number"
                value={monthlyInvestment}
                onChange={(e) => setMonthlyInvestment(e.target.value)}
                className="text-lg"
                placeholder="Enter monthly SIP amount"
              />
              <p className="text-sm text-text-secondary mt-1">
                ₹{parseFloat(monthlyInvestment).toLocaleString("en-IN") || 0}
              </p>
            </div>

            <div>
              <Label htmlFor="expectedReturn" className="text-base font-semibold mb-2 block">
                Expected Return Rate (% per annum)
              </Label>
              <Input
                id="expectedReturn"
                type="number"
                step="0.1"
                value={expectedReturn}
                onChange={(e) => setExpectedReturn(e.target.value)}
                className="text-lg"
                placeholder="Enter expected return rate"
              />
            </div>

            <div>
              <Label htmlFor="timePeriod" className="text-base font-semibold mb-2 block">
                Time Period (Years)
              </Label>
              <Input
                id="timePeriod"
                type="number"
                value={timePeriod}
                onChange={(e) => setTimePeriod(e.target.value)}
                className="text-lg"
                placeholder="Enter investment period"
              />
            </div>

            <Button
              onClick={calculateSIP}
              className="w-full gradient-bg text-white font-semibold text-lg py-6 rounded-xl hover:scale-105 transition-transform shadow-lg"
            >
              Calculate Returns
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-6">Investment Summary</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-cyan/10 to-purple/10 border border-cyan/20">
                <span className="text-text-secondary font-medium">Total Value</span>
                <span className="text-2xl font-bold gradient-text">
                  ₹{totalValue.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                <span className="text-text-secondary font-medium">Total Investment</span>
                <span className="text-xl font-semibold">
                  ₹{totalInvestment.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                <span className="text-text-secondary font-medium">Estimated Returns</span>
                <span className="text-xl font-semibold text-green">
                  ₹{estimatedReturns.toLocaleString("en-IN")}
                </span>
              </div>
            </div>
          </Card>

          {/* Pie Chart */}
          {totalValue > 0 && (
            <Card className="p-6 lg:p-8 glass-effect">
              <h3 className="font-manrope text-xl font-bold mb-4">Returns Distribution</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `₹${value.toLocaleString("en-IN")}`} />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          )}
        </div>
      </div>

      {/* Growth Chart */}
      {chartData.length > 0 && (
        <Card className="p-6 lg:p-8 glass-effect mt-6">
          <h3 className="font-manrope text-xl font-bold mb-4">Investment Growth Over Time</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="year" />
              <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(0)}L`} />
              <Tooltip formatter={(value: number) => `₹${value.toLocaleString("en-IN")}`} />
              <Legend />
              <Line
                type="monotone"
                dataKey="invested"
                stroke="#00D4FF"
                strokeWidth={3}
                name="Invested Amount"
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#8B5CF6"
                strokeWidth={3}
                name="Total Value"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}
    </CalculatorLayout>
  );
};

export default SIPCalculator;
