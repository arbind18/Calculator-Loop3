import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import CalculatorLayout from "@/components/CalculatorLayout";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

const EMICalculator = () => {
  const [principal, setPrincipal] = useState<string>("1000000");
  const [rate, setRate] = useState<string>("8.5");
  const [tenure, setTenure] = useState<string>("20");
  const [emi, setEmi] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);
  const [totalAmount, setTotalAmount] = useState<number>(0);

  const calculateEMI = () => {
    const P = parseFloat(principal);
    const r = parseFloat(rate) / 12 / 100; // Monthly interest rate
    const n = parseFloat(tenure) * 12; // Total months

    if (P > 0 && r > 0 && n > 0) {
      const emiValue = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalAmountValue = emiValue * n;
      const totalInterestValue = totalAmountValue - P;

      setEmi(Math.round(emiValue));
      setTotalInterest(Math.round(totalInterestValue));
      setTotalAmount(Math.round(totalAmountValue));
    }
  };

  const chartData = [
    { name: "Principal Amount", value: parseFloat(principal) || 0 },
    { name: "Total Interest", value: totalInterest },
  ];

  const COLORS = ["#00D4FF", "#8B5CF6"];

  return (
    <CalculatorLayout
      title="EMI Calculator"
      description="Calculate your monthly loan EMI with detailed breakdown"
      icon="💰"
    >
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Input Section */}
        <Card className="p-6 lg:p-8 glass-effect">
          <h3 className="font-manrope text-xl font-bold mb-6">Loan Details</h3>
          <div className="space-y-6">
            <div>
              <Label htmlFor="principal" className="text-base font-semibold mb-2 block">
                Loan Amount (₹)
              </Label>
              <Input
                id="principal"
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(e.target.value)}
                className="text-lg"
                placeholder="Enter loan amount"
              />
              <p className="text-sm text-text-secondary mt-1">
                ₹{parseFloat(principal).toLocaleString("en-IN") || 0}
              </p>
            </div>

            <div>
              <Label htmlFor="rate" className="text-base font-semibold mb-2 block">
                Interest Rate (% per annum)
              </Label>
              <Input
                id="rate"
                type="number"
                step="0.1"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                className="text-lg"
                placeholder="Enter interest rate"
              />
            </div>

            <div>
              <Label htmlFor="tenure" className="text-base font-semibold mb-2 block">
                Loan Tenure (Years)
              </Label>
              <Input
                id="tenure"
                type="number"
                value={tenure}
                onChange={(e) => setTenure(e.target.value)}
                className="text-lg"
                placeholder="Enter loan tenure"
              />
            </div>

            <Button
              onClick={calculateEMI}
              className="w-full gradient-bg text-white font-semibold text-lg py-6 rounded-xl hover:scale-105 transition-transform shadow-lg"
            >
              Calculate EMI
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-6">EMI Breakdown</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-cyan/10 to-purple/10 border border-cyan/20">
                <span className="text-text-secondary font-medium">Monthly EMI</span>
                <span className="text-2xl font-bold gradient-text">
                  ₹{emi.toLocaleString("en-IN")}
                </span>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                <span className="text-text-secondary font-medium">Principal Amount</span>
                <span className="text-xl font-semibold">
                  ₹{parseFloat(principal).toLocaleString("en-IN") || 0}
                </span>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                <span className="text-text-secondary font-medium">Total Interest</span>
                <span className="text-xl font-semibold">₹{totalInterest.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                <span className="text-text-secondary font-medium">Total Amount</span>
                <span className="text-xl font-semibold">₹{totalAmount.toLocaleString("en-IN")}</span>
              </div>
            </div>
          </Card>

          {/* Chart */}
          {emi > 0 && (
            <Card className="p-6 lg:p-8 glass-effect">
              <h3 className="font-manrope text-xl font-bold mb-4">Payment Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `₹${value.toLocaleString("en-IN")}`} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          )}
        </div>
      </div>
    </CalculatorLayout>
  );
};

export default EMICalculator;
