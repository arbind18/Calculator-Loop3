import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import CalculatorLayout from "@/components/CalculatorLayout";

const GSTCalculator = () => {
  const [amount, setAmount] = useState<string>("1000");
  const [gstRate, setGstRate] = useState<string>("18");
  const [calculationType, setCalculationType] = useState<string>("exclusive");
  const [gstAmount, setGstAmount] = useState<number>(0);
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [netAmount, setNetAmount] = useState<number>(0);

  const calculateGST = () => {
    const amt = parseFloat(amount);
    const rate = parseFloat(gstRate) / 100;

    if (amt > 0 && rate >= 0) {
      if (calculationType === "exclusive") {
        // GST Exclusive (Add GST to amount)
        const gst = amt * rate;
        setGstAmount(Math.round(gst * 100) / 100);
        setNetAmount(Math.round(amt * 100) / 100);
        setTotalAmount(Math.round((amt + gst) * 100) / 100);
      } else {
        // GST Inclusive (Extract GST from amount)
        const net = amt / (1 + rate);
        const gst = amt - net;
        setGstAmount(Math.round(gst * 100) / 100);
        setNetAmount(Math.round(net * 100) / 100);
        setTotalAmount(Math.round(amt * 100) / 100);
      }
    }
  };

  return (
    <CalculatorLayout
      title="GST Calculator"
      description="Calculate GST on products and services with ease"
      icon="📊"
    >
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Input Section */}
        <Card className="p-6 lg:p-8 glass-effect">
          <h3 className="font-manrope text-xl font-bold mb-6">GST Calculation</h3>
          <div className="space-y-6">
            <div>
              <Label className="text-base font-semibold mb-3 block">Calculation Type</Label>
              <RadioGroup value={calculationType} onValueChange={setCalculationType}>
                <div className="flex items-center space-x-2 p-3 rounded-lg bg-muted">
                  <RadioGroupItem value="exclusive" id="exclusive" />
                  <Label htmlFor="exclusive" className="flex-1 cursor-pointer">
                    GST Exclusive (Add GST)
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-3 rounded-lg bg-muted">
                  <RadioGroupItem value="inclusive" id="inclusive" />
                  <Label htmlFor="inclusive" className="flex-1 cursor-pointer">
                    GST Inclusive (Remove GST)
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="amount" className="text-base font-semibold mb-2 block">
                {calculationType === "exclusive" ? "Net Amount (₹)" : "Total Amount (₹)"}
              </Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="text-lg"
                placeholder="Enter amount"
              />
              <p className="text-sm text-text-secondary mt-1">
                ₹{parseFloat(amount).toLocaleString("en-IN") || 0}
              </p>
            </div>

            <div>
              <Label htmlFor="gstRate" className="text-base font-semibold mb-2 block">
                GST Rate (%)
              </Label>
              <div className="grid grid-cols-4 gap-2 mb-3">
                {["5", "12", "18", "28"].map((rate) => (
                  <Button
                    key={rate}
                    variant={gstRate === rate ? "default" : "outline"}
                    onClick={() => setGstRate(rate)}
                    className={gstRate === rate ? "gradient-bg" : ""}
                  >
                    {rate}%
                  </Button>
                ))}
              </div>
              <Input
                id="gstRate"
                type="number"
                step="0.1"
                value={gstRate}
                onChange={(e) => setGstRate(e.target.value)}
                className="text-lg"
                placeholder="Enter GST rate"
              />
            </div>

            <Button
              onClick={calculateGST}
              className="w-full gradient-bg text-white font-semibold text-lg py-6 rounded-xl hover:scale-105 transition-transform shadow-lg"
            >
              Calculate GST
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-6">GST Breakdown</h3>
            {totalAmount > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-cyan/10 to-purple/10 border border-cyan/20">
                  <span className="text-text-secondary font-medium">Total Amount</span>
                  <span className="text-2xl font-bold gradient-text">
                    ₹{totalAmount.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                  <span className="text-text-secondary font-medium">Net Amount</span>
                  <span className="text-xl font-semibold">
                    ₹{netAmount.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                  <span className="text-text-secondary font-medium">GST Amount ({gstRate}%)</span>
                  <span className="text-xl font-semibold text-cyan">
                    ₹{gstAmount.toLocaleString("en-IN")}
                  </span>
                </div>

                {/* CGST & SGST Breakdown */}
                <div className="mt-6 p-4 rounded-xl bg-secondary/50 border border-border">
                  <h4 className="font-semibold mb-3">GST Split</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-text-secondary">CGST ({parseFloat(gstRate) / 2}%)</span>
                      <span className="font-semibold">₹{(gstAmount / 2).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-secondary">SGST ({parseFloat(gstRate) / 2}%)</span>
                      <span className="font-semibold">₹{(gstAmount / 2).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-text-secondary">
                Enter amount and click calculate to see GST breakdown
              </div>
            )}
          </Card>

          {/* GST Rate Info */}
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-4">Common GST Rates</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between p-3 rounded-lg bg-muted">
                <span>Essential goods</span>
                <span className="font-semibold text-cyan">5%</span>
              </div>
              <div className="flex justify-between p-3 rounded-lg bg-muted">
                <span>Standard goods</span>
                <span className="font-semibold text-cyan">12%</span>
              </div>
              <div className="flex justify-between p-3 rounded-lg bg-muted">
                <span>Most goods & services</span>
                <span className="font-semibold text-cyan">18%</span>
              </div>
              <div className="flex justify-between p-3 rounded-lg bg-muted">
                <span>Luxury items</span>
                <span className="font-semibold text-cyan">28%</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </CalculatorLayout>
  );
};

export default GSTCalculator;
