import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";

const AgeCalculator = () => {
  const [birthDate, setBirthDate] = useState<Date>();
  const [targetDate, setTargetDate] = useState<Date>(new Date());
  const [ageDetails, setAgeDetails] = useState<any>(null);

  const calculateAge = () => {
    if (!birthDate) return;

    const birth = new Date(birthDate);
    const target = new Date(targetDate);

    let years = target.getFullYear() - birth.getFullYear();
    let months = target.getMonth() - birth.getMonth();
    let days = target.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += prevMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDays = Math.floor((target.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);
    const totalMonths = years * 12 + months;
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;

    // Calculate next birthday
    let nextBirthday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday < target) {
      nextBirthday.setFullYear(nextBirthday.getFullYear() + 1);
    }
    const daysToNextBirthday = Math.ceil((nextBirthday.getTime() - target.getTime()) / (1000 * 60 * 60 * 24));

    setAgeDetails({
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      totalMonths,
      totalHours,
      totalMinutes,
      daysToNextBirthday,
      nextBirthday,
    });
  };

  return (
    <CalculatorLayout
      title="Age Calculator"
      description="Calculate your exact age in years, months, days, and more"
      icon="🎂"
    >
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Input Section */}
        <Card className="p-6 lg:p-8 glass-effect">
          <h3 className="font-manrope text-xl font-bold mb-6">Date Selection</h3>
          <div className="space-y-6">
            <div>
              <Label className="text-base font-semibold mb-2 block">Date of Birth</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal text-lg h-12"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {birthDate ? format(birthDate, "PPP") : <span>Pick your birth date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={birthDate}
                    onSelect={setBirthDate}
                    initialFocus
                    disabled={(date) => date > new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label className="text-base font-semibold mb-2 block">Calculate Age On</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal text-lg h-12"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {targetDate ? format(targetDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={targetDate}
                    onSelect={(date) => date && setTargetDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <Button
              onClick={calculateAge}
              disabled={!birthDate}
              className="w-full gradient-bg text-white font-semibold text-lg py-6 rounded-xl hover:scale-105 transition-transform shadow-lg"
            >
              Calculate Age
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-6">Your Age</h3>
            {ageDetails ? (
              <div className="space-y-4">
                <div className="p-6 rounded-2xl bg-gradient-to-r from-cyan/10 to-purple/10 border border-cyan/20 text-center">
                  <div className="text-5xl font-bold gradient-text mb-2">
                    {ageDetails.years} Years
                  </div>
                  <div className="text-xl text-text-secondary">
                    {ageDetails.months} Months, {ageDetails.days} Days
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 rounded-xl bg-muted text-center">
                    <div className="text-2xl font-bold text-cyan">{ageDetails.totalMonths}</div>
                    <div className="text-sm text-text-secondary">Total Months</div>
                  </div>
                  <div className="p-4 rounded-xl bg-muted text-center">
                    <div className="text-2xl font-bold text-purple">{ageDetails.totalWeeks.toLocaleString()}</div>
                    <div className="text-sm text-text-secondary">Total Weeks</div>
                  </div>
                  <div className="p-4 rounded-xl bg-muted text-center">
                    <div className="text-2xl font-bold text-cyan">{ageDetails.totalDays.toLocaleString()}</div>
                    <div className="text-sm text-text-secondary">Total Days</div>
                  </div>
                  <div className="p-4 rounded-xl bg-muted text-center">
                    <div className="text-2xl font-bold text-purple">{ageDetails.totalHours.toLocaleString()}</div>
                    <div className="text-sm text-text-secondary">Total Hours</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-text-secondary">
                Select your birth date and click calculate
              </div>
            )}
          </Card>

          {ageDetails && (
            <Card className="p-6 lg:p-8 glass-effect">
              <h3 className="font-manrope text-xl font-bold mb-4">Next Birthday</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-pink/10 to-purple/10 border border-pink/20">
                  <span className="text-text-secondary font-medium">Date</span>
                  <span className="text-lg font-semibold">
                    {format(ageDetails.nextBirthday, "PPP")}
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                  <span className="text-text-secondary font-medium">Days Remaining</span>
                  <span className="text-lg font-semibold text-cyan">
                    {ageDetails.daysToNextBirthday} days
                  </span>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-muted">
                  <span className="text-text-secondary font-medium">You'll Turn</span>
                  <span className="text-lg font-semibold text-purple">
                    {ageDetails.years + 1} years old
                  </span>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </CalculatorLayout>
  );
};

export default AgeCalculator;
