import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import CalculatorLayout from "@/components/CalculatorLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const BMICalculator = () => {
  const [height, setHeight] = useState<string>("170");
  const [weight, setWeight] = useState<string>("70");
  const [bmi, setBmi] = useState<number>(0);
  const [category, setCategory] = useState<string>("");
  const [categoryColor, setCategoryColor] = useState<string>("");

  const calculateBMI = () => {
    const h = parseFloat(height) / 100; // Convert cm to meters
    const w = parseFloat(weight);

    if (h > 0 && w > 0) {
      const bmiValue = w / (h * h);
      setBmi(parseFloat(bmiValue.toFixed(1)));

      // Determine category
      if (bmiValue < 18.5) {
        setCategory("Underweight");
        setCategoryColor("text-cyan");
      } else if (bmiValue >= 18.5 && bmiValue < 25) {
        setCategory("Normal weight");
        setCategoryColor("text-green");
      } else if (bmiValue >= 25 && bmiValue < 30) {
        setCategory("Overweight");
        setCategoryColor("text-yellow-500");
      } else {
        setCategory("Obese");
        setCategoryColor("text-pink");
      }
    }
  };

  const getBMIIndicatorPosition = () => {
    if (bmi === 0) return 0;
    if (bmi < 18.5) return (bmi / 18.5) * 25;
    if (bmi < 25) return 25 + ((bmi - 18.5) / (25 - 18.5)) * 25;
    if (bmi < 30) return 50 + ((bmi - 25) / (30 - 25)) * 25;
    return Math.min(75 + ((bmi - 30) / 10) * 25, 100);
  };

  return (
    <CalculatorLayout
      title="BMI Calculator"
      description="Calculate your Body Mass Index and understand your health status"
      icon="⚖️"
    >
      <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Input Section */}
        <Card className="p-6 lg:p-8 glass-effect">
          <h3 className="font-manrope text-xl font-bold mb-6">Your Measurements</h3>
          <Tabs defaultValue="metric" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="metric">Metric</TabsTrigger>
              <TabsTrigger value="imperial">Imperial</TabsTrigger>
            </TabsList>
            <TabsContent value="metric" className="space-y-6">
              <div>
                <Label htmlFor="height" className="text-base font-semibold mb-2 block">
                  Height (cm)
                </Label>
                <Input
                  id="height"
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  className="text-lg"
                  placeholder="Enter your height"
                />
              </div>

              <div>
                <Label htmlFor="weight" className="text-base font-semibold mb-2 block">
                  Weight (kg)
                </Label>
                <Input
                  id="weight"
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="text-lg"
                  placeholder="Enter your weight"
                />
              </div>
            </TabsContent>
            <TabsContent value="imperial" className="space-y-6">
              <div>
                <Label className="text-base font-semibold mb-2 block">Height (feet & inches)</Label>
                <div className="grid grid-cols-2 gap-4">
                  <Input type="number" placeholder="Feet" className="text-lg" />
                  <Input type="number" placeholder="Inches" className="text-lg" />
                </div>
              </div>

              <div>
                <Label className="text-base font-semibold mb-2 block">Weight (lbs)</Label>
                <Input type="number" placeholder="Enter weight" className="text-lg" />
              </div>
            </TabsContent>
          </Tabs>

          <Button
            onClick={calculateBMI}
            className="w-full gradient-bg text-white font-semibold text-lg py-6 rounded-xl hover:scale-105 transition-transform shadow-lg mt-6"
          >
            Calculate BMI
          </Button>
        </Card>

        {/* Results Section */}
        <div className="space-y-6">
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-6">Your BMI Result</h3>
            {bmi > 0 ? (
              <div className="space-y-6">
                <div className="text-center p-6 rounded-2xl bg-gradient-to-r from-cyan/10 to-purple/10 border border-cyan/20">
                  <div className="text-6xl font-bold gradient-text mb-2">{bmi}</div>
                  <div className={`text-xl font-semibold ${categoryColor}`}>{category}</div>
                </div>

                {/* BMI Scale Indicator */}
                <div className="space-y-3">
                  <div className="h-8 rounded-full overflow-hidden flex">
                    <div className="w-1/4 bg-cyan"></div>
                    <div className="w-1/4 bg-green"></div>
                    <div className="w-1/4 bg-yellow-500"></div>
                    <div className="w-1/4 bg-pink"></div>
                  </div>
                  <div className="relative h-6">
                    <div
                      className="absolute w-1 h-6 bg-foreground rounded-full transition-all duration-500"
                      style={{ left: `${getBMIIndicatorPosition()}%`, transform: "translateX(-50%)" }}
                    >
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-foreground text-background px-2 py-1 rounded text-xs font-bold">
                        {bmi}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between text-xs text-text-secondary">
                    <span>Underweight</span>
                    <span>Normal</span>
                    <span>Overweight</span>
                    <span>Obese</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-text-secondary">
                Enter your measurements and click calculate to see your BMI
              </div>
            )}
          </Card>

          {/* BMI Categories Info */}
          <Card className="p-6 lg:p-8 glass-effect">
            <h3 className="font-manrope text-xl font-bold mb-4">BMI Categories</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                <span className="font-medium">Underweight</span>
                <span className="text-cyan font-semibold">&lt; 18.5</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                <span className="font-medium">Normal weight</span>
                <span className="text-green font-semibold">18.5 - 24.9</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                <span className="font-medium">Overweight</span>
                <span className="text-yellow-500 font-semibold">25 - 29.9</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                <span className="font-medium">Obese</span>
                <span className="text-pink font-semibold">≥ 30</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </CalculatorLayout>
  );
};

export default BMICalculator;
